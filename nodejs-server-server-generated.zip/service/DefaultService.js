'use strict';


/**
 * Create new checklist
 *
 * body Checklist 
 * returns ChecklistsCollection
 **/
exports.createChecklist = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete checklist
 *
 * id Integer checklist id
 * no response value expected for this operation
 **/
exports.deleteChecklist = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get checklist by id
 *
 * id Integer checklist id
 * returns Checklist
 **/
exports.getChecklist = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get all checklists
 *
 * returns ChecklistsCollection
 **/
exports.getChecklists = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get api info
 *
 * returns ApiHealthInfo
 **/
exports.getHealthInfo = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update checklist
 *
 * body Checklist 
 * id Integer checklist id
 * returns Checklist
 **/
exports.patchChecklist = function(bodyid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

