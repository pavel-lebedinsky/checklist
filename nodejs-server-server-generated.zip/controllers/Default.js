'use strict';

var utils = require('../utils/writer.js');
var Default = require('../service/DefaultService');

module.exports.createChecklist = function createChecklist (req, res, next) {
  var body = req.swagger.params['body'].value;
  Default.createChecklist(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteChecklist = function deleteChecklist (req, res, next) {
  var id = req.swagger.params['id'].value;
  Default.deleteChecklist(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getChecklist = function getChecklist (req, res, next) {
  var id = req.swagger.params['id'].value;
  Default.getChecklist(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getChecklists = function getChecklists (req, res, next) {
  Default.getChecklists()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getHealthInfo = function getHealthInfo (req, res, next) {
  Default.getHealthInfo()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.patchChecklist = function patchChecklist (req, res, next) {
  var body = req.swagger.params['body'].value;
  var id = req.swagger.params['id'].value;
  Default.patchChecklist(bodyid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
